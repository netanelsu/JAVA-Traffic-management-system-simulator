package components;

import utilities.Timer;
import utilities.Utilities;

import java.util.ArrayList;

/**
 * aoop20 Hm2
 * @author eyal bismuth - 308200203
 * @author netanel sudai - 316004878
 *
 * class Trafficlights a abstract class to extend that reprsent a trafficlight in the map
 */
public abstract class TrafficLights extends Thread implements Timer, Utilities {
    private boolean trafficLightsOn;
    private static int objectsCount = 0;
    private int delay;
    private int greenLightIndex;
    private int id;
    private static final int minDelay = 2;
    private static final int maxDelay = 6;
    private ArrayList<Road> roads;
    private int workingTime;

    /**
     * constructor that receives junction entering roads and intilazie al parameter
     * traffic lights set to false by default
     * @param roads junction entering road
     */
    public TrafficLights(ArrayList<Road> roads) {
        this.roads = roads;
        objectsCount ++;
        id = objectsCount;
        trafficLightsOn = false ;
        delay = this.getRandomInt(minDelay,maxDelay + 1);
        greenLightIndex = -1;
        workingTime = delay;
    }

    /**
     * abstract method to control the priority of the roads
     */
    public abstract void changeIndex();

    @Override
    public void run() {
        super.run();
        while (Driving.isRun()){
            try {
                Thread.sleep(100);
                while (Driving.isStop()){
                    if(!Driving.isRun()){
                        return;
                    }
                    synchronized (this) {
                        this.wait();
                    }
                }
                incrementDrivingTime();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * change the priority of road according to green light index
     */

    public void changeLights(){
        changeIndex();
        for(Road r: roads){
            if(roads.indexOf(r) == greenLightIndex){
                r.setGreenlight(true);
                System.out.println(r + ": green light");
            }
            else
                r.setGreenlight(false);
        }


    }

    /**
     * checks if it time to update roads priority and does it if necessary
     */
    public void incrementDrivingTime(){
        synchronized (this) {
            while (!Driving.isRun()){
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (workingTime == 0) {
                changeLights();
                workingTime = delay;
            } else {
                workingTime--;
                System.out.println("- on delay");
            }
        }
        try {
            sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public boolean isTrafficLightsOn() {
        return trafficLightsOn;
    }

    /**
     * turn the traffic light on
     * @param trafficLightsOn -true/false = On/off
     */
    public void setTrafficLightsOn(boolean trafficLightsOn) {
        this.trafficLightsOn = trafficLightsOn;
        System.out.println(this + " " + id + " turned ON, delay time: " + delay);
        changeLights();
    }

    public static int getObjectsCount() {
        return objectsCount;
    }

    public static void setObjectsCount(int objectsCount) {
        TrafficLights.objectsCount = objectsCount;
    }

    public int getDelay() {
        return delay;
    }

    public void setDelay(int delay) {
        this.delay = delay;
    }

    public int getGreenLightIndex() {
        return greenLightIndex;
    }

    public void setGreenLightIndex(int greenLightIndex) {
        this.greenLightIndex = greenLightIndex;
    }

    public long getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static int getMinDelay() {
        return minDelay;
    }

    public static int getMaxDelay() {
        return maxDelay;
    }

    public ArrayList<Road> getRoads() {
        return roads;
    }

    public void setRoads(ArrayList<Road> roads) {
        this.roads = roads;
    }

    public int getWorkingTime() {
        return workingTime;
    }

    public void setWorkingTime(int workingTime) {
        this.workingTime = workingTime;
    }
    public synchronized void Resume(){
        this.notify();
    }
}
