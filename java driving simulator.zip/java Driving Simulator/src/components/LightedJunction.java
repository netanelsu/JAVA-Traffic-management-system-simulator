package components;

import java.util.Objects;
import java.util.Random;

/**
 * aoop20 Hm2
 * @author eyal bismuth - 308200203
 * @author netanel sudai - 316004878
 *  class LightedJunction extend Junction represent a Junction with traffic lights
 */
public class LightedJunction extends Junction {

    private TrafficLights lights;

    /**
     * default constructor initialize the traffic light type
     */
    public LightedJunction() {
        super();
        if(this.getRandomBoolean()){
            lights = new RandomTrafficLights(this.enteringRoads);
        }
        else {
            lights = new SequentialTrafficLights(this.enteringRoads);
        }
    }

    /**
     * a constrctor with given parameter
     * @param junctionName - junc name
     * @param x - x axe location
     * @param y - y axe location
     * @param sequential type
     * @param lightsOn if light is on/off
     */
    public LightedJunction(String junctionName, double x, double y,boolean sequential, boolean lightsOn) {
        super(junctionName, x, y);
        if(sequential){
            lights = new SequentialTrafficLights(this.enteringRoads);
        }
        else {
            lights =new RandomTrafficLights(this.enteringRoads);
        }
        lights.setTrafficLightsOn(lightsOn);
    }

    public TrafficLights getLights() {
        return lights;
    }

    public void setLights(TrafficLights lights) {
        this.lights = lights;
    }

    /**
     * calc the estimated time to go threw the junction for a given vehicle
     * @param obj - vehicle
     * @return Time amount to pass the junction
     */
    public double calcEstimatedTime(Object obj){
        return lights.getDelay() * (enteringRoads.size() - 1) + 1;
    }

    /**
     * Routeparts interface method check vehicle priority according to road light
     * @param vehicle - vehicle
     * @return true / false
     */
    @Override
    public boolean canLeave(Vehicle vehicle) {
        if(lights.isTrafficLightsOn()){
            if(vehicle.getLastRoad().isGreenlight()){
                return true;
            }
            return false;
        }
        return super.canLeave(vehicle);

    }

    @Override
    public String toString() {
        return "Junction " + this.junctionName + " (Lighted)";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LightedJunction)) return false;
        if (!super.equals(o)) return false;
        LightedJunction that = (LightedJunction) o;
        return Objects.equals(lights, that.lights);
    }
}
