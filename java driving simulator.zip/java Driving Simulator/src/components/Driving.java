package components;

import utilities.Timer;
import utilities.Utilities;
import Gui.*;

import java.util.ArrayList;

/**
 * aoop20 Hm2
 * @author eyal bismuth - 308200203
 * @author netanel sudai - 316004878
 *
 * class driving control our game and represnet vehicles driving in a game map
 * working as a thread that repaint my gui frame every 100 mill.
 */
public class Driving extends Thread implements Utilities, Timer {
    public Map getMap() {
        return map;
    }
    private Map map;
    private ArrayList<Vehicle> vehicles;
    private int drivingTime;
    private ArrayList<Timer> allTimedElements;
    private static boolean run = true;
    private static boolean Stop = false;

    /**
     * constructor builds a map with given amount of junction , connects all the junction with roads and create vehicles
     * with a given number
     * @param numOfJunctions - junction number
     * @param numOfVehicles - vehicles number
     */
    public Driving(int numOfJunctions, int numOfVehicles){
        map = new Map(numOfJunctions);
        allTimedElements = new ArrayList<Timer>(1);
        vehicles = new ArrayList<Vehicle>(1);
        System.out.println("================= CREATING VEHICLES =================");
        for(int i = 0 ; i < numOfVehicles;i ++){
            vehicles.add(new Vehicle(map.getRoads().get(this.getRandomInt(0,map.getRoads().size()))));
            allTimedElements.add(vehicles.get(vehicles.size() - 1));
        }
        for(int j = 0; j < map.getLights().size(); j++){
            if(map.getLights().get(j).isTrafficLightsOn()){
                allTimedElements.add(map.getLights().get(j));
            }
        }
    }

    /**
     * a method that control the game and moving all the cars in the map in every turn for a given amount of turns
     * @param numOfTurns
     */
    public void drive(int numOfTurns){
        System.out.println("================= START DRIVING=================");
        for(int i = 0; i < numOfTurns; i++){
            System.out.println("***************TURN " + i + " ***************");
            incrementDrivingTime();
            graphics.getMainframe().repaint();

        }
    }

    /**
     * thread run override that repaint my main frame an goes to sleep for 100 mill.
     * wait statement happens when stop button of gui has been clicked
     */
    @Override
    public void run() {
        super.run();
        while (run) {
            try {
                Thread.sleep(100);
                while (Driving.isStop()){
                    if(!isRun()){
                        return;
                    }
                    synchronized (this) {
                        this.wait();
                    }
                }
                graphics.getMainframe().repaint();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
//            try {
//                sleep(100);
//                for (Timer t : allTimedElements) {
//                    (new Thread(t)).start();
//                }
//                graphics.getMainframe().repaint();
//            } catch (InterruptedException e) {
//                e.printStackTrace();
        }
    }

    /**
     * increment all timed elements(Vehicles Traffic lights) driving time and data with Timer api
     */
    @Override
    public void incrementDrivingTime() {
        for (Timer allTimedElement : allTimedElements) {
            System.out.println(allTimedElement);
            allTimedElement.incrementDrivingTime();
            System.out.println("");
        }
    }
    public ArrayList<Vehicle> getVehicles() {
        return vehicles;
    }

    public static boolean isRun() {
        return run;
    }

    public static void setRun(boolean run) {
        Driving.run = run;
    }

    public ArrayList<Timer> getAllTimedElements() {
        return allTimedElements;
    }

    public static boolean isStop() {
        return Stop;
    }

    public static void setStop(boolean stop) {
        Stop = stop;
    }

    /**
     * method that resuming thread work by notifying every vehicle and trafficlights objects waiting list
     * and eventually notifying the driving object
     *
     */
    public synchronized void Resume(){
        setStop(false);
        for(Timer t: allTimedElements){
            t.Resume();
        }
        this.notify();
    }
}
