package components;

import utilities.VehicleType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;
import java.util.Random;

/**
 * aoop20 Hm2
 * @author eyal bismuth - 308200203
 * @author netanel sudai - 316004878
 * class Route represent a Route of roads and junction in the program
 */
public class Route implements RouteParts {

    private ArrayList<RouteParts> RouteParts;
    private Vehicle vehicle;

    /**
     * constructor to initialize a randomise Route for a given vehicle from a given start junction
     *  route mac size is 10 route parts or less if the randomise junction does not include roads that fits the vehicle
     * @param start - start junction
     * @param vehicle - vehicle that driving the route
     */
    public Route(RouteParts start, Vehicle vehicle) {
       int counter = 0;
       this.vehicle = vehicle;
       RouteParts temp;
       if(start instanceof Road) {
           setRouteParts(new ArrayList<RouteParts>(1));
           getRouteParts().add(start);
           getRouteParts().add(start.findNextPart(vehicle));
           while (counter < 8) {
               temp = getRouteParts().get(getRouteParts().size() - 1).findNextPart(vehicle);
               if(temp != null && !getRouteParts().contains(temp)){
                   getRouteParts().add(temp);
               }
               else{
                   break;
               }
               counter ++;
           }
       }
       temp = getRouteParts().get(getRouteParts().size() - 1);
       if (temp instanceof Road){
           getRouteParts().add(((Road) temp).getEndJunction());
       }
       System.out.println("- is starting a new " + this) ;
    }

    /**
     * calc route estimated drive time of the vehicle
     * @param obj
     * @return time for vehicle to drive threw the route
     */
    @Override
    public double calcEstimatedTime(Object obj) {
        int size = getRouteParts().size();
        double Time = 0;
        for (int i = 0 ; i < size;i++){
            Time += getRouteParts().get(i).calcEstimatedTime(vehicle);
        }
        return Time;
    }

    /**
     * checks if the vehicle finished the route
     * @param vehicle -
     * @return true / false
     */
    @Override
    public boolean canLeave(Vehicle vehicle) {
        return vehicle.getCurrentRoutePart() == getRouteParts().get(getRouteParts().size() - 1);
    }

    /**
     * check in the vehicle to the route
     * @param vehicle
     */
    @Override
    public void checkIn(Vehicle vehicle) {
      System.out.println("- is starting a new Route from " + this);
      getRouteParts().get(0).checkIn(vehicle);
    }

    /**
     * check out the vehicle from the route
     * @param vehicle
     */
    @Override
    public void checkout(Vehicle vehicle) {
        System.out.println("has finished the " + this);
        vehicle.setCurrentRoute((Route) this.findNextPart(vehicle));

    }

    /**
     * build a new route for the vehicle .
     * @param vehicle
     * @return new route
     */
    public RouteParts findNextPart(Vehicle vehicle){
        if(!canLeave(vehicle)){
            return vehicle.getCurrentRoute().getRouteParts().get(vehicle.getCurrentRoute().getRouteParts().
                    indexOf(vehicle.getCurrentRoutePart()) + 1);
        }
        else{
            RouteParts temp = vehicle.getCurrentRoutePart();
            if(((Junction)temp).checkAvailability(vehicle)){
                return new Route(temp.findNextPart(vehicle),vehicle);
            }
            return new Route(vehicle.getCurrentRoute().getRouteParts().get(0),vehicle);
        }
    }

    /**
     * still moving on the route
     * @param vehicle
     */
    @Override
    public void stayOnCurrentPart(Vehicle vehicle) {

    }

    /**
     * getter for route parts
     * @return route_parts array
     */
    public ArrayList<components.RouteParts> getRouteParts() {
        return RouteParts;
    }
    /**
     * setter for route parts
     * @param routeParts - value to set
     */

    public void setRouteParts(ArrayList<components.RouteParts> routeParts) {
        RouteParts = routeParts;
    }

    /**
     * getter for vehicle
     * @return vehicle
     */
    public Vehicle getVehicle() {
        return vehicle;
    }

    /**
     * setter for vehicle
     * @param vehicle - vehicle to set
     */
    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    /**
     * to string override
     * @return a string that represnt the route
     */
    @Override
    public String toString() {
        return "Route from " +
                 getRouteParts().get(0) + " to " + getRouteParts().get(getRouteParts().size() - 1) + ", estimated time for\n" +
                "route: " + calcEstimatedTime(this.vehicle) + ".";

    }

    /**
     * equals override
     * @param o - object to compare tp
     * @return true/false
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Route)) return false;
        Route route = (Route) o;
        return Objects.equals(RouteParts, route.RouteParts) &&
                Objects.equals(vehicle, route.vehicle);
    }
}
