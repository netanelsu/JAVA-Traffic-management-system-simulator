package components;

import utilities.Utilities;

import java.util.ArrayList;
import java.util.Objects;

/**
 * aoop20 Hm2
 * @author eyal bismuth - 308200203
 * @author netanel sudai - 316004878
 * class that represent game map with all junction and roads
 */
public class Map implements Utilities {
    ArrayList<Junction> junctions;
    ArrayList<Road> roads;
    ArrayList<TrafficLights> lights;

    /**
     * constructor that build random junction with given number and creates road between al of them.
     * @param numOfJunctions - number of wanted junction
     */
    public Map(int numOfJunctions) {
        LightedJunction temp;
        junctions = new ArrayList<Junction>(numOfJunctions);
        roads = new ArrayList<Road>(1);
        lights = new ArrayList<TrafficLights>(1);
        System.out.println("================= CREATING JUNCTIONS=================");
        for(int i = 0 ; i < numOfJunctions; i++) {
            if (this.getRandomBoolean()) {
                temp = new LightedJunction();
                junctions.add(temp);
                lights.add(temp.getLights());
            } else {
                junctions.add(new Junction());

            }
        }
        SetAllRoads();
//        for (Junction j : junctions){
//            if(j instanceof LightedJunction){
//                if(this.getRandomBoolean()){
//                    ((LightedJunction) j).setLights(new RandomTrafficLights(j.enteringRoads));
//                    lights.add(((LightedJunction) j).getLights());
//                }
//                else {
//                    ((LightedJunction) j).setLights(new SequentialTrafficLights(j.enteringRoads));
//                    lights.add(((LightedJunction) j).getLights());
//                }
//            }
//        }
        turnLightsOn();
        System.out.println("\n ================= GAME MAP HAS BEEN CREATED =================");
    }

    /**
     *  method to set the traffic lights on
     */
    public void turnLightsOn(){
        System.out.println("\n ================= TRAFFIC LIGHTS TURN ON =================");
        for(TrafficLights Tf : lights){
            if(this.getRandomBoolean()){
                Tf.setTrafficLightsOn(true);
            }
        }
    }

    /**
     * method to create the roads
     */
    public void SetAllRoads(){
        System.out.println("\n ================= CREATING ROADS================= ");
        for(int i = 0 ;i < junctions.size(); i ++){
            for (int j = 0;j < junctions.size();j ++){
                if(i != j){
                    roads.add(new Road(junctions.get(i),junctions.get(j)));
                }
            }
        }
    }

    @Override
    public String toString() {
        return "Map{" +
                "junctions=" + junctions +
                ", roads=" + roads +
                ", lights=" + lights +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Map)) return false;
        Map map = (Map) o;
        return Objects.equals(junctions, map.junctions) &&
                Objects.equals(roads, map.roads) &&
                Objects.equals(lights, map.lights);
    }


    public ArrayList<Junction> getJunctions() {
        return junctions;
    }

    public void setJunctions(ArrayList<Junction> junctions) {
        this.junctions = junctions;
    }

    public ArrayList<Road> getRoads() {
        return roads;
    }

    public void setRoads(ArrayList<Road> roads) {
        this.roads = roads;
    }

    public ArrayList<TrafficLights> getLights() {
        return lights;
    }

    public void setLights(ArrayList<TrafficLights> lights) {
        this.lights = lights;
    }
}
