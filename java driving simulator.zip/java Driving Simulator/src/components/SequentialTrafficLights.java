package components;

import java.util.ArrayList;
import java.util.Objects;

/**
 *  class SequentialTrafficLights extends TrafficLights represent a Sequential type of Traffic Lights
 */
public class SequentialTrafficLights extends TrafficLights {
    private int increment;
    public SequentialTrafficLights(ArrayList<Road> roads) {
        super(roads);
    }

    /**
     * a method that change the priority index
     */
    @Override
    public void changeIndex() {
        if(this.getGreenLightIndex() == this.getRoads().size() || this.getGreenLightIndex() == -1){
            this.setGreenLightIndex(0);
        }
        else {
            this.setGreenLightIndex(this.getGreenLightIndex() + 1);
        }

    }

    @Override
    public String toString() {
        return "Sequential traffic lights " + getId();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SequentialTrafficLights)) return false;
        SequentialTrafficLights that = (SequentialTrafficLights) o;
        return increment == that.increment;
    }

}
