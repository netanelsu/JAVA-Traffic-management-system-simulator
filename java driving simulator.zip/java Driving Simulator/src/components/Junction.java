package components;

import utilities.Point;

import java.util.ArrayList;
import java.util.Objects;

/**
 * aoop20 Hm2
 * @author eyal bismuth - 308200203
 * @author netanel sudai - 316004878
 * class junction inherite point - represent roads intersection in the program
 *@see Point location of the junction
 *@see RouteParts - interface for route parts includes roads,junction ...
 */
public class Junction extends Point implements RouteParts {
    private static int objectsCount = 0;
    ArrayList<Road> enteringRoads = null;
    ArrayList<Road> exitingRoads = null;
    String junctionName;

    /**
     * default constructor that uses Point default constructor to randomise a location for the junction.
     * also update object count field and the according to it
     */
    public Junction() {
        super();
        enteringRoads = new ArrayList<Road>(1);
        exitingRoads = new ArrayList<Road>(1);
        objectsCount ++;
        junctionName = String.valueOf(objectsCount);
        this.successMessage(toString());
    }

    /**
     * a cosntructor that initialize with given values
     * @param junctionName - junction name
     * @param x - x for Point constructor
     * @param y - y for Point constructor
     */
    public Junction(String junctionName, double x, double y) {
        super(x, y);
        objectsCount ++;
        this.junctionName = junctionName;
    }

    /**
     * getter for entering roads to the junction array
     * @return entering roads array
     */
    public ArrayList<Road> getEnteringRoads() {
        return enteringRoads;
    }

    /**
     * setter for entering roads array
     * @param enteringRoads - entering roads value
     */
    public void setEnteringRoads(ArrayList<Road> enteringRoads) {
        this.enteringRoads = enteringRoads;
    }

    /**
     * getter for exiting roads to the junction array
     * @return exiting roads array
     */
    public ArrayList<Road> getExitingRoads() {
        return exitingRoads;
    }

    /**
     * setter for exiting roads array
     * @param exitingRoads - exiting roads value
     */
    public void setExitingRoads(ArrayList<Road> exitingRoads) {
        this.exitingRoads = exitingRoads;
    }

    /**
     * getter for junction name
     * @return junction name
     */
    public String getJunctionName() {
        return junctionName;
    }

    /**
     * setter for junction name
     * @param junctionName - junction name value
     */
    public void setJunctionName(String junctionName) {
        this.junctionName = junctionName;
    }

    /**
     * add road to entering road array
     * @param road - entering road value to insert to the array
     */
    public void addEnteringRoad(Road road){
        if (enteringRoads == null){
            enteringRoads = new ArrayList<Road>(1);
        }
        enteringRoads.add(road);
    }
    /**
     * add road to exiting road array
     * @param road - exiting road value to insert to the array
     */
    public void addExitingRoad(Road road){
        if (exitingRoads == null){
            exitingRoads = new ArrayList<Road>(1);
        }
        exitingRoads.add(road);
    }

    /**
     * calc estimated time for a vehicle to leave the junction
     * @param obj - vehicle
     * @return the time to go threw the junction
     */
    @Override
    public double calcEstimatedTime(Object obj) {
        return exitingRoads.indexOf(((Vehicle) obj).getLastRoad()) + 1;
    }

    /**
     * checks if vehicle can leave the junction
     * @param vehicle
     * @return true/false
     */
    @Override
    public boolean canLeave(Vehicle vehicle) {
//        if(checkAvailability(vehicle)){
//            Road temp = (Road)vehicle.getCurrentRoute().getRouteParts().get(vehicle.getCurrentRoute().getRouteParts().indexOf(this) + 1);
//            return temp.isGreenlight();
//        }
//        return false;
        return checkAvailability(vehicle);
    }

    /**
     * check in a vehicle into the junction
     * @param vehicle
     */
    @Override
    public void checkIn(Vehicle vehicle) {
        vehicle.setCurrentRoutePart(this);
        System.out.println("- has arrived to " + this);
    }

    /**
     * checkout a vehicle from the junction
     * @param vehicle
     */
    @Override
    public void checkout(Vehicle vehicle) {
        //vehicle.getLastRoad().removeVehicleFromWaitingVehicles(vehicle);
        //vehicle.getCurrentRoute().findNextPart(vehicle).checkIn(vehicle);
        System.out.println("- has left the " + this + ".");
    }

    /**
     * interface method that finds an exiting road from the junction that a given vehicle can drive on
     * @param vehicle
     * @return a road that fits the vehicle or null if there are any
     */
    @Override
    public RouteParts findNextPart(Vehicle vehicle) {
        if (exitingRoads != null) {
            int counter = 0,size = exitingRoads.size();
            int i = this.getRandomInt(0, size);
           while(counter < size) {
                if (exitingRoads.get(i).isEnable()) {
                    for (int j = 0; j < exitingRoads.get(i).getVehicleTypes().length; j++) {
                        if (vehicle.getVehicleType() == exitingRoads.get(i).getVehicleTypes()[j]) {
                            return exitingRoads.get(i);
                        }
                    }
                }
                i++;
                if(i == size){
                    i = 0;
                }
                counter++;
            }
        }
        return null;
    }

    /**
     * interface method that prints that a vehicle still remains in the junction
     * @param vehicle
     */
    @Override
    public void stayOnCurrentPart(Vehicle vehicle) {
        System.out.println("- is waiting at Junction " + this.junctionName+ " - there are cars on roads with higher priority.");
    }

    /**
     * a private method to check if a there is an exiting road that enabled fits vehicle type and priority
     * @param vehicle
     * @return true false
     */
    public boolean checkAvailability(Vehicle vehicle){
        if(exitingRoads != null) {
            for (Road exitingRoad : exitingRoads) {
                if (exitingRoad.isEnable()) {
                    for (int i = 0; i < exitingRoad.getVehicleTypes().length; i++) {
                        if(vehicle.getVehicleType() == exitingRoad.getVehicleTypes()[i]
                            && vehicle.getLastRoad().getWaitingVehicles().get(0) == vehicle){
                            return true;
                        }
                    }
                }

            }
        }
        return false;
    }

    /**
     * to string override
     * @return string that represent the junction
     */
    @Override
    public String toString() {
        return "Junction " + junctionName;
    }

    /**
     * equals override
     * @param o object to compare to
     * @return true/false
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Junction)) return false;
        if (!super.equals(o)) return false;
        Junction junction = (Junction) o;
        return Objects.equals(enteringRoads, junction.enteringRoads) &&
                Objects.equals(exitingRoads, junction.exitingRoads) &&
                Objects.equals(junctionName, junction.junctionName);
    }

}
