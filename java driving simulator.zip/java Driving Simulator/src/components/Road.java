package components;

import utilities.Utilities;
import utilities.VehicleType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

/**
 * aoop20 Hm2
 * @author eyal bismuth - 308200203
 * @author netanel sudai - 316004878
 * class Road represnt a road between to junctions
 * @see RouteParts,Utilities;
 */
public class Road implements RouteParts, Utilities {
    private static final int [] allowedSpeedOptions = {30,40,50,55,60,70,80,90};
    private boolean enable;
    private Junction startJunction;
    private Junction endJunction;
    private boolean greenlight;
    private double length;
    private int maxSpeed;
    private VehicleType[] vehicleTypes;
    private ArrayList <Vehicle> waitingVehicles;

    /**
     * constructor that get starting junction and end junction and initialize the values with it
     * enabled value is randomise
     * @param startJunction - start junction
     * @param endJunction - end junction
     */
    public Road(Junction startJunction, Junction endJunction) {
        this.startJunction = startJunction;
        this.endJunction = endJunction;
        waitingVehicles = new ArrayList<Vehicle>(1);
        startJunction.addExitingRoad(this);
        endJunction.addEnteringRoad(this);
        enable = this.getRandomBoolean();
        greenlight = false;
        length = calcLength();
        maxSpeed = allowedSpeedOptions[this.getRandomInt(0,allowedSpeedOptions.length)];
        int tempstart = this.getRandomInt(0,(int) VehicleType.values().length / 2);
        int tempend = this.getRandomInt(VehicleType.values().length / 2, VehicleType.values().length);
        int k = tempstart;
        vehicleTypes = new VehicleType[tempend - tempstart + 1];
        for(int i = 0 ; i < tempend - tempstart + 1; i ++){
            vehicleTypes[i] = VehicleType.values()[k];
            k++;
        }
        waitingVehicles = null;
        System.out.println(this + " has been created.");


    }

    /**
     * equals override
     * @param o - object to compare to
     * @return true/false
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Road)) return false;
        Road road = (Road) o;
        return enable == road.enable &&
                greenlight == road.greenlight &&
                Double.compare(road.length, length) == 0 &&
                maxSpeed == road.maxSpeed &&
                Objects.equals(startJunction, road.startJunction) &&
                Objects.equals(endJunction, road.endJunction) &&
                Arrays.equals(vehicleTypes, road.vehicleTypes) &&
                Objects.equals(waitingVehicles, road.waitingVehicles);
    }

    /**
     * tostring override
     * @return strings that represent a road
     */
    @Override
    public String toString() {
        return "Road from " + startJunction + " to " + endJunction + ", length: " + length +"" +
                ", max speed: " + getMaxSpeed();
    }

    /**
     * getter for allowed speed options
     * @return allowed speed options array
     */
    public static int[] getAllowedSpeedOptions() {
        return allowedSpeedOptions;
    }

    /**
     * getter for is enable
     * @return enable
     */
    public boolean isEnable() {
        return enable;
    }

    /**
     * setter for enable
     * @param enable enable value
     */
    public void setEnable(boolean enable) {
        this.enable = enable;
    }

    /**
     * getter for start junction
     * @return start junction
     */
    public Junction getStartJunction() {
        return startJunction;
    }

    /**
     * setter for start junction
     * @param startJunction - value to set
     */
    public void setStartJunction(Junction startJunction) {
        this.startJunction = startJunction;
    }

    /**
     * getter for end junction
     * @return end junction
     */
    public Junction getEndJunction() {
        return endJunction;
    }

    /**
     * setter for end junction
     * @param endJunction - value to set
     */
    public void setEndJunction(Junction endJunction) {
        this.endJunction = endJunction;
    }

    /**
     * getter for greenlight(priority) field
     * @return greenlight
     */
    public boolean isGreenlight() {
        return greenlight;
    }

    /**
     * setter for greenlight(priority) field
     * @param greenlight - value to set
     */
    public void setGreenlight(boolean greenlight) {
        this.greenlight = greenlight;
    }

    /**
     * getter for max speed
     * @return max speed
     */
    public int getMaxSpeed() {
        return maxSpeed;
    }

    /**
     * setter for max speed
     * @param maxSpeed - value to set
     */
    public void setMaxSpeed(int maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    /**
     * getter for vehicles types
     * @return vehicle_type array
     */
    public VehicleType[] getVehicleTypes() {
        return vehicleTypes;
    }

    /**
     * setter for vehicles types
     * @param vehicleTypes - value to set
     */
    public void setVehicleTypes(VehicleType[] vehicleTypes) {
        this.vehicleTypes = vehicleTypes;
    }

    /**
     * getter for waiting_vehicles
     * @return waiting vehicle array
     */
    public ArrayList<Vehicle> getWaitingVehicles() {
        return waitingVehicles;
    }

    /**
     * setter for waiting vehicles
     * @param waitingVehicles - value to set
     */
    public void setWaitingVehicles(ArrayList<Vehicle> waitingVehicles) {
        this.waitingVehicles = waitingVehicles;
    }

    /**
     * getter for road length
     * @return road length
     */
    public double getLength() {
        return length;
    }
    /**
     * setter for road length
     * @param length - value to set
     */
    public void setLength(double length) {
        this.length = length;
    }

    /**
     * a method that calc road length
     * @return road length
     */
    public double calcLength(){
        return startJunction.calcDistance(endJunction);
    }

    /**
     * calc estimated time for a given vehicle to finish the road
     * @param obj - vehicle to check
     * @return estimated road drive finish time
     */
    @Override
    public double calcEstimatedTime(Object obj) {
        Vehicle tempV = (Vehicle) obj;
        double temp = this.length / Math.min(tempV.getVehicleType().getAverageSpeed(),this.getMaxSpeed());
        return Math.round(temp);
    }

    /**
     *  interface method that check if a vehicle finished the road
     * @param vehicle - vehicle to check
     * @return true / false
     */
    @Override
    public boolean canLeave(Vehicle vehicle) {
        return vehicle.getTimeOnCurrentPart() >= calcEstimatedTime(vehicle);
    }

    /**
     * check in a vehicle to the road
     * @param vehicle - vehicle to check in
     */
    @Override
    public void checkIn(Vehicle vehicle) {
        if(vehicle.getLastRoad() != null){
            vehicle.getLastRoad().removeVehicleFromWaitingVehicles(vehicle);
        }
        vehicle.setLastRoad(this);
        vehicle.setCurrentRoutePart(this);
        System.out.println("- is starting to move on " + this +  " time to finish: " + this.calcEstimatedTime(vehicle));
    }

    /**
     * check out a vehicle from the road
     * @param vehicle
     */
    @Override
    public void checkout(Vehicle vehicle) {
        this.addVehicleToWaitingVehicles(vehicle);
        System.out.println("has finished " + this + ",  time spent on the road: " + vehicle.getTimeOnCurrentPart());

    }

    /**
     * returns the next part in the route parts
     * @param vehicle
     * @return road end junction
     */
    @Override
    public RouteParts findNextPart(Vehicle vehicle) {
        return endJunction;
    }

    /**
     * prints a message that prints that the vehicle is still moving on the road
     * @param vehicle
     */
    @Override
    public void stayOnCurrentPart(Vehicle vehicle) {
        System.out.println("- is still moving on " + this +" time to arrive: " + (this.calcEstimatedTime(vehicle) - vehicle.getTimeOnCurrentPart()));
    }

    /**
     * add vehicle to waiting list
     * @param vehicle
     */
    public void addVehicleToWaitingVehicles(Vehicle vehicle){
        if(this.waitingVehicles == null){
            this.waitingVehicles = new ArrayList<Vehicle>(1);
        }
        this.waitingVehicles.add(vehicle);
    }

    /**
     * remove vehicle to waiting list
     * @param vehicle
     */
    public void removeVehicleFromWaitingVehicles(Vehicle vehicle){
        this.waitingVehicles.remove(vehicle);
    }
}
