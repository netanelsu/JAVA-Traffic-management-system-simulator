package components;

import java.util.ArrayList;

/**
 * class RandomTrafficLights extends TrafficLights represent a Random type of Traffic Lights
 */
public class RandomTrafficLights extends TrafficLights {
    public RandomTrafficLights(ArrayList<Road> roads) {
        super(roads);

    }
    /**
     * a method that change the priority index
     */
    @Override
    public void changeIndex() {
        if(this.getGreenLightIndex() >= this.getRoads().size()){
            this.setGreenLightIndex(0);
        }
        else if(this.getGreenLightIndex() == -1){
            this.setGreenLightIndex(this.getRandomInt(0,getRoads().size()));
        }
        else {
            this.setGreenLightIndex(this.getGreenLightIndex() + 1);
        }
    }

    @Override
    public String toString() {
        return "Random traffic lights " + getId();
    }


}
