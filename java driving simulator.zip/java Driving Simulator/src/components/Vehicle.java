package components;

import utilities.Point;
import utilities.Timer;
import utilities.Utilities;
import utilities.VehicleType;

import java.awt.*;
import java.util.concurrent.locks.Lock;

/**
 * aoop20 Hm2
 * @author eyal bismuth - 308200203
 * @author netanel sudai - 316004878
 * class Vehivle represent a vehicle in the game with type id route..
 */
public class Vehicle extends Thread implements  Timer, Utilities {
    private VehicleType vehicleType;
    private int id;
    private int x;
    private int y;
    private Route currentRoute;
    private RouteParts currentRoutePart;
    private int timeFromRouteStart;
    private int timeOnCurrentPart;
    private static int objectsCount = 0;
    private Road lastRoad;
    private String status;
    private Color color;

    /**
     * a constructor that receive first road and builds a vehicle and a route that he fits to
     * @param road - first route road
     */
    public Vehicle(Road road) {
        objectsCount ++;
        id = objectsCount;
        vehicleType = road.getVehicleTypes()[this.getRandomInt(0,road.getVehicleTypes().length)];
        color = Color.BLUE;
        this.lastRoad = road;
        currentRoutePart = road;
        timeOnCurrentPart = 0;
        timeFromRouteStart = 0;
        System.out.println("Vehicle " + id +": " + vehicleType + ", average speed: " + vehicleType.getAverageSpeed() +" has been created.");
        currentRoute = new Route(road,this);
        x = (int)lastRoad.getStartJunction().getX();
        y = (int)lastRoad.getStartJunction().getY();
        status = "- is starting to move on " + road.toString();
        System.out.println(status);
    }

    /**
     * Thread run override operating the vehicle movement and goes to sleep for 100 mill
     * when stop gui button is clicked the thread reaches the wait statement.
     */
    @Override
    public void run() {
        super.run();
        synchronized (this) {
            while (Driving.isRun()) {
                try {
                    sleep(100);
                    while (Driving.isStop()) {
                        if (!Driving.isRun()) {
                            return;
                        }
                        this.wait();
                    }
                    incrementDrivingTime();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * a method to move the vehicle threw the route with the use of the route parts interface methods
     */
    public void move(){
        System.out.println(this);
        if(this.currentRoutePart.canLeave(this)) {
            this.currentRoutePart.checkout(this);
            if (!this.currentRoute.canLeave(this)) {
                this.currentRoute.findNextPart(this).checkIn(this);
                if (this.currentRoute.canLeave(this)){
                    System.out.println("- has finished the " + this.currentRoute);
                    this.setCurrentRoute((Route) currentRoute.findNextPart(this));
                    this.currentRoute.getRouteParts().get(0).checkIn(this);
                }

            }
            else {
                //this.currentRoute.getRouteParts().get(this.currentRoute.getRouteParts().size() - 1).checkIn(this);
                this.setCurrentRoute((Route) currentRoute.findNextPart(this));
                this.currentRoute.getRouteParts().get(0).checkIn(this);
            }
        }
        else {
            this.currentRoutePart.stayOnCurrentPart(this);
            int left = (int)lastRoad.getLength() - (int)(this.getVehicleType().getAverageSpeed())* timeOnCurrentPart;
            int passed = (int)lastRoad.getLength() - left;
            x = (int)(lastRoad.getStartJunction().getX() * left + lastRoad.getEndJunction().getX()* passed)/(passed + left);
            y = (int)(lastRoad.getStartJunction().getY() * left + lastRoad.getEndJunction().getY()* passed)/(passed + left);


        }

    }

    /**
     * Timer interface method that increment the driving time of the vehicle in every turn
     */
    @Override
    public void incrementDrivingTime() {
        this.timeOnCurrentPart += 1;
        this.timeFromRouteStart += 1;
        move();
    }
    public long getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Route getCurrentRoute() {
        return currentRoute;
    }

    public void setCurrentRoute(Route currentRoute) {
        this.currentRoute = currentRoute;
    }

    public RouteParts getCurrentRoutePart() {
        return currentRoutePart;
    }

    public void setCurrentRoutePart(RouteParts currentRoutePart) {
        this.currentRoutePart = currentRoutePart;
        timeOnCurrentPart = 0;
    }

    public int getTimeFromRouteStart() {
        return timeFromRouteStart;
    }

    public void setTimeFromRouteStart(int timeFromRouteStart) {
        this.timeFromRouteStart = timeFromRouteStart;
    }

    public int getTimeOnCurrentPart() {
        return timeOnCurrentPart;
    }

    public void setTimeOnCurrentPart(int timeOnCurrentPart) {
        this.timeOnCurrentPart = timeOnCurrentPart;
    }

    public static int getObjectsCount() {
        return objectsCount;
    }

    public static void setObjectsCount(int objectsCount) {
        Vehicle.objectsCount = objectsCount;
    }

    public Road getLastRoad() {
        return lastRoad;
    }

    public void setLastRoad(Road lastRoad) {
        this.lastRoad = lastRoad;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(VehicleType vehicleType) {
        this.vehicleType = vehicleType;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * notifying the vehicle from waiting list
     */
    public synchronized void Resume(){
        this.notify();
    }

    @Override
    public String toString() {
        return "Vehicle " + getId() +": " + getVehicleType()
                + ", average speed: "
                + getVehicleType().getAverageSpeed();
    }
}
