package Gui;

import components.Junction;
import components.LightedJunction;
import components.Road;
import components.Vehicle;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Path2D;
import java.util.ArrayList;

/**
 * class mypanel extend pannel and represent our drawing "canvas"
 */
public class Mypanel extends JPanel {
    private ArrayList<Junction> junctions;
    private ArrayList<Road> roads;
    private ArrayList<Vehicle> vehicles;

    /**
     * default constructor
     */
    public Mypanel(){
        super();
        this.setSize(new Dimension(800,600));
        setBackground(Color.WHITE);
        setVisible(true);
        validate();
    }

    /**
     * constructor that gets junctions roads and vehicles and initialize the panel parameters
     * @param junctions - program junctions
     * @param roads - program roads
     * @param vehicles - program vehicles
     */
    public Mypanel(ArrayList<Junction> junctions, ArrayList<Road> roads, ArrayList<Vehicle> vehicles) {
        this.junctions = junctions;
        this.roads = roads;
        this.vehicles = vehicles;
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(800,600));
        setVisible(true);
    }

    /**
     * paint component override to draw the junctions roads and vehicles on my panel.
     * if there a lighted junction with working trraficlights it's also paint a green arrow head near the current green road
     * @param g
     */
   @Override
   public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (junctions != null) {
            for(Junction j : junctions){
                if(!(j instanceof LightedJunction)){
                    g.setColor(Color.BLACK);
                }
                else {
                if(((LightedJunction) j).getLights().isTrafficLightsOn()){
                    g.setColor(Color.RED);

                }
                else {
                    g.setColor(Color.GREEN);
                }
            }
            g.fillOval((int)j.getX(),(int)j.getY(),20,20);
           }
            g.setColor(Color.black);
           for(Road r: roads){
               g.drawLine((int)r.getStartJunction().getX() + 10, (int)r.getStartJunction().getY() + 10,
                       (int)r.getEndJunction().getX() + 10, (int)r.getEndJunction().getY() + 10);
               if(r.getEndJunction() instanceof LightedJunction &&
                       ((LightedJunction) r.getEndJunction()).getLights().isTrafficLightsOn() &&
                       r.isGreenlight()){
                   g.setColor(Color.green);
                   drawArrowLine(g,(int)r.getStartJunction().getX() + 10,(int)r.getStartJunction().getY(),
                           (int)r.getEndJunction().getX()  + 10,(int)r.getEndJunction().getY() + 10,10,5 );
                   g.setColor(Color.black);
               }
           }
           for(Vehicle v: vehicles){
               drawRotetedVehicle(this.getGraphics(),v.getX() + 10,v.getY() + 10
               ,(int)v.getLastRoad().getEndJunction().getX(),(int)v.getLastRoad().getEndJunction().getY(),10,4,v.getColor());

           }
        }
    }

    /**
     * draw vehicles
     * @param g
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @param d
     * @param h
     * @param Vehicle_Color
     */
    private void drawRotetedVehicle(Graphics g, int x1, int y1, int x2, int y2, int d, int h , Color Vehicle_Color){
        int dx = x2 - x1, dy = y2 - y1, delta = 10;
        double D = Math.sqrt(dx*dx + dy*dy);
        double xm = delta, xn = xm, ym = h, yn = -h, x;
        double xm1 = delta + d, xn1 = xm1, ym1 = h, yn1 = -h, xx;
        double sin = dy / D, cos = dx / D;
        x = xm*cos - ym*sin + x1;
        xx = xm1*cos - ym1*sin + x1;
        ym = xm*sin + ym*cos + y1;
        ym1 = xm1*sin + ym1*cos + y1;
        xm = x;
        xm1 = xx;
        x = xn*cos - yn*sin + x1;
        xx = xn1*cos - yn1*sin + x1;
        yn = xn*sin + yn*cos + y1;
        yn1 = xn1*sin + yn1*cos + y1;
        xn = x;
        xn1 = xx;
        int[] xpoints = {(int) xm1, (int) xn1,  (int) xn, (int) xm};
        int[] ypoints = {(int) ym1, (int) yn1, (int) yn, (int) ym};
        g.setColor(Vehicle_Color);
        g.fillPolygon(xpoints, ypoints, 4);
        g.setColor(Color.BLACK);
        g.fillOval((int) xm1-2,(int) ym1-2,4,4);
        g.fillOval((int) xn1-2,(int) yn1-2,4,4);
        g.fillOval((int) xm-2,(int) ym-2,4,4);
        g.fillOval((int) xn-2,(int) yn-2,4,4);

    }

    /**
     * draw road with green arrowhead that represent green light road
     * @param g
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @param d
     * @param h
     */
    private void drawArrowLine(Graphics g, int x1, int y1, int x2, int y2, int d, int h) {
        int dx = x2 - x1, dy = y2 - y1;
        double D = Math.sqrt(dx*dx + dy*dy);
        double xm = D - d, xn = xm, ym = h, yn = -h, x;
        double sin = dy / D, cos = dx / D;

        x = xm*cos - ym*sin + x1;
        ym = xm*sin + ym*cos + y1;
        xm = x;

        x = xn*cos - yn*sin + x1;
        yn = xn*sin + yn*cos + y1;
        xn = x;

        int[] xpoints = {x2, (int) xm, (int) xn};
        int[] ypoints = {y2, (int) ym, (int) yn};
//        g.setColor(Color.black);
//        g.drawLine(x1, y1, x2, y2);
        g.setColor(Color.green);
        g.fillPolygon(xpoints, ypoints, 3);
    }
}
