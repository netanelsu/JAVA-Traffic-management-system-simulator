package Gui;

import components.*;
import utilities.Timer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.print.PrinterException;
import java.util.Random;
import java.util.Vector;

/**
 * Graphics class creates and operates the visualization of our program.
 * has a drawing panel that paint the vehicles junctions and roads.
 */
public class graphics {
    private Driving game = null;
    private JScrollPane scrollPane;
    private boolean infoFlag = true;
    private static JFrame mainframe;
    private JPanel gamebuttons;
    private Mypanel drawings;
    private JMenuBar menuBar;
    private JButton Create_Road_button;
    private JButton Start_button;
    private JButton Stop_button;
    private JButton Resume_button;
    private JButton info_button;
    private Font f12 = new Font("Times New Roman", 0, 12);
    private Font f121 = new Font("Times New Roman", 1, 12);

    /**
     * a constructor that builds button pannel and Mypannel(drawing pannel) and add them to the frame
     * also adds a menu bar .
     */
    public graphics(){
        Create_pannel();
        if(drawings == null) {
            drawings = new Mypanel();
        }
        Create_menubar();
        mainframe = new JFrame("Road system");
        //mainframe.setSize(800,400);
        mainframe.setSize(new Dimension(800,680));
        mainframe.setVisible(true);
        mainframe.setJMenuBar(menuBar);
        mainframe.setLayout(new GridLayout(1,0));
        mainframe.add(drawings);
        mainframe.setLayout(new BorderLayout());
        mainframe.add(gamebuttons,BorderLayout.SOUTH);
        mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        drawings.setPreferredSize(new Dimension(800,600));

    }

    /**
     * creates main frame menu bar with options to set background to drawing paneel, paint the car in diffrent colors,
     * show a table with all car stats
     */
    public void Create_menubar(){
        JMenu File, Background, Vehicles_color, Help;
        JMenuItem exit, Blue, None, Magneta, Orange, Random, help,Blue2;
        File = new JMenu("File");
        File.setFont(f121);
        File.setMnemonic(KeyEvent.VK_F);
        exit = new JMenuItem("Exit");
        exit.setFont(f12);
        exit.setAccelerator(KeyStroke.getKeyStroke( KeyEvent.VK_X,
                InputEvent.CTRL_MASK));
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        File.add(exit);
        Background = new JMenu("Background");
        Background.setFont(f121);
        Blue = new JMenuItem("Blue");
        None = new JMenuItem("None");
        Blue.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               drawings.setBackground(Color.blue);
            }
        });
        None.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                drawings.setBackground(Color.WHITE);
            }
        });
        Background.add(Blue);
        Background.add(None);
        Vehicles_color = new JMenu("Vehicles color");
        Vehicles_color.setFont(f121);
        Blue2 = new JMenuItem("Blue");
        Blue2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (Vehicle v: game.getVehicles()){
                    v.setColor(Color.BLUE);
                }
                mainframe.repaint();
            }
        });
        Magneta = new JMenuItem("Magenta");
        Magneta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (Vehicle v: game.getVehicles()){
                    v.setColor(Color.MAGENTA);
                }
                mainframe.repaint();
            }
        });
        Orange = new JMenuItem("Orange");
        Orange.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (Vehicle v: game.getVehicles()){
                    v.setColor(Color.ORANGE);
                }
                mainframe.repaint();
            }
        });
        Random = new JMenuItem("Random");
        Random.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Color[] c = {Color.BLUE,Color.BLACK,Color.GREEN,Color.RED,Color.orange,Color.magenta};
                Random random = new Random();
                for (Vehicle v: game.getVehicles()){
                    v.setColor(c[random.nextInt(5)]);
                }
                mainframe.repaint();
            }
        });

        Vehicles_color.add(Blue2);
        Vehicles_color.add(Magneta);
        Vehicles_color.add(Orange);
        Vehicles_color.add(Random);
        Help = new JMenu("Help");
        Help.setFont(f121);
        help = new JMenuItem("Help");
        help.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(mainframe,"Home Work 3 \n GUI @ Threads");
            }
        });
        Help.add(help);
        menuBar = new JMenuBar();
        menuBar.setLayout(new GridLayout(1,0));
        menuBar.add(File);
        menuBar.add(Background);
        menuBar.add(Vehicles_color);
        menuBar.add(Help);

    }

    /**
     * creates button pannel.
     * create Road system - creates a new driving session with cars junction and roads
     * start - start all program threads
     * stop - stop all program threads
     * resume - resume all current threads run
     * info - representing a table with al vehicles data
     */
    public void Create_pannel(){
        gamebuttons = new JPanel();
        Create_Road_button = new JButton("Create Road System");
        Create_Road_button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Driving.setRun(false);
                if(game != null){
                    game.Resume();
                    try {
                        game.join();
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }
                JFrame j = new JFrame("Create Road System");
                JPanel pannel = new JPanel();
                JPanel JuncPannel = new JPanel();
                JPanel carpannel = new JPanel();
                JLabel junc = new JLabel("Number of junctions");
                JLabel car = new JLabel("Number of Vehicles");
                JButton ok = new JButton("Ok");
                JButton cancel = new JButton("Cancel");
                j.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                JSlider slide1,slide2;
                slide1 = new JSlider(3,20,3);
                slide2 = new JSlider(0,50,0);
                //slide1.set
                slide1.setMajorTickSpacing(1);
                slide1.setMinorTickSpacing(1);
                slide1.setPaintTicks(true);
                slide1.setPaintLabels(true);
                slide2.setMajorTickSpacing(5);
                slide2.setMinorTickSpacing(1);
                slide2.setPaintTicks(true);
                slide2.setPaintLabels(true);
                JuncPannel.setLayout(new GridLayout(2,0));
                JuncPannel.add(junc,BorderLayout.NORTH);
                JuncPannel.add(slide1);
                carpannel.setLayout(new GridLayout(2,0));
                carpannel.add(car,BorderLayout.CENTER);
                carpannel.add(slide2);
                pannel.setLayout(new GridLayout(1,2));
                pannel.add(ok);
                pannel.add(cancel);
                j.setLayout(new BorderLayout());
                j.add(JuncPannel,BorderLayout.NORTH);
                j.add(carpannel,BorderLayout.CENTER);
                j.add(pannel,BorderLayout.SOUTH);
                ok.setPreferredSize(new Dimension(290,30));
                j.setSize(new Dimension(600,300));
                j.setLocation((int)j.getWidth()/2,(int)j.getHeight()/2);
                j.setVisible(true);
                ok.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        j.setVisible(false);
                        game = new Driving(slide1.getValue(),slide2.getValue());
                        drawings = new Mypanel(game.getMap().getJunctions(),game.getMap().getRoads(),game.getVehicles());
                        mainframe.add(drawings,0);
                        mainframe.repaint();
                    }
                });
            }
        });
        Start_button = new JButton("Start");
        Start_button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Driving.setRun(true);
                for (Timer t : game.getAllTimedElements()) {
                    (new Thread(t)).start();
                }
                if(game.isAlive()){
                    game.interrupt();
                }
                game.start();
            }
        });
        Stop_button = new JButton("Stop");
        Stop_button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Driving.setStop(true);
            }
        });
        Resume_button = new JButton("Resume");
        Resume_button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.Resume();
            }
        });
        info_button = new JButton("info");
        info_button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(infoFlag){
                    infoFlag = false;
                    Vector <String> culomns = new Vector<>();
                    Vector<Vector<String>> table_data = new Vector<>(game.getVehicles().size());
                    Vector<String> row = new Vector<>();
                    if(game == null){
                        return;
                    }
                    for(Vehicle v: game.getVehicles()) {
                        row.add(String.valueOf(v.getId()));
                        row.add(v.getVehicleType().name());
                        if (v.getCurrentRoutePart() instanceof Road) {
                            row.add("Road " + ((Road) v.getCurrentRoutePart()).getStartJunction().getJunctionName() + "-"
                                    + ((Road) v.getCurrentRoutePart()).getEndJunction().getJunctionName());
                        }
                        if (v.getCurrentRoutePart() instanceof Junction) {
                            row.add("Junction" + ((Junction) v.getCurrentRoutePart()).getJunctionName());
                        }
                        row.add("" + v.getTimeOnCurrentPart());
                        row.add("" + v.getVehicleType().getAverageSpeed() * 10);
                        table_data.add(row);
                        row = new Vector<>();
                    }
                    culomns.add("Vehicle #");
                    culomns.add("Type");
                    culomns.add("Location");
                    culomns.add("Time on Loc");
                    culomns.add("Speed");
                    JTable j = new JTable(table_data, culomns);
                    scrollPane = new JScrollPane(j);
                    scrollPane.setBounds(0, 0, 400, 150);
                    j.setFillsViewportHeight(true);
                    drawings.add(scrollPane);
                }
                else {
                    scrollPane.setVisible(false);
                    mainframe.repaint();
                    infoFlag = true;
                }

            }
        });
        gamebuttons.setLayout(new GridLayout(1,0));
        gamebuttons.add(Create_Road_button);
        gamebuttons.add(Start_button);
        gamebuttons.add(Stop_button);
        gamebuttons.add(Resume_button);
        gamebuttons.add(info_button);

    }

    public static JFrame getMainframe() {
        return mainframe;
    }

}


