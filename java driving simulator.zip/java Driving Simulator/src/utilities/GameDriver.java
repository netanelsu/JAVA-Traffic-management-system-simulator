package utilities;


import Gui.graphics;
import components.Driving;

/**
 * class game driver is the main class that operates our game.
 */
public class GameDriver {
    public static void main(String[] args) {
//        Driving driving=new Driving(10, 20);
//       driving.drive(20);
        graphics g = new graphics();
    }

}
