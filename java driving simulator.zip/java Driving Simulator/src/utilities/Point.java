package utilities;


/**
 * aoop20 Hm2
 * @author eyal bismuth - 308200203
 * @author netanel sudai - 316004878
 * abstract class point represnt a location by x y axis
 * @param minVal a minimum value for x and y
 * @param maxX max value for x
 * @param maxY max value for y
 * @param x represent x axe
 * @param y represent y axe
 * @see Utilities - interface for neccesary tools
 */


public abstract class Point implements Utilities{
    private final static double minVal = 0;
    private final static double maxX = 800;
    private final static double maxY = 600;
    private double x;
    private double y;

    /**
     * constructor that set x and y values, if wrong values accepted it randomise new values
     * @param x - x value
     * @param y - y value
     */
    public Point(double x, double y) {
        if(checkValue(x,minVal,maxX) && checkValue(y,minVal,maxY)){
            this.x = x;
            this.y = y;
        }
        else {
            if(!checkValue(x,minVal,maxX)){
                errorMessage(x,"X");
                this.x = getRandomDouble(minVal,maxX);
                correctingMessage(x,this.x,"X");
            }
            if(!checkValue(y,minVal,maxY)){
                errorMessage(y,"Y");
                this.y = getRandomDouble(minVal,maxX);
                correctingMessage(y,this.y,"Y");
            }
        }
    }

    /**
     * default constructor randomise values for x and y
     */
    public Point() {
        this.x = getRandomDouble(minVal,maxX);
        this.y = getRandomDouble(minVal,maxY);
    }

    /**
     * calc the distance between to points
     * @param other - value to measure to
     * @return distance between the points
     */
    public double calcDistance(Point other){
        return Math.sqrt(Math.pow(x - other.getX(),2) + Math.pow(y - other.getY(),2));
    };

    /**
     * to string override
     * @return string that represent the class
     */
    @Override
    public String toString() {
        return "Point(" +
                "x=" + x +
                ", y=" + y +
                ')';
    }

    /**
     * equals override
     * @param o object to compare to
     * @return true/false
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Point)) return false;
        Point point = (Point) o;
        return Double.compare(point.x, x) == 0 &&
                Double.compare(point.y, y) == 0;
    }

    /**
     * getter for minval
     * @return mival
     */
    public static double getMinVal() {
        return minVal;
    }

    /**
     * getter for maxx
     * @return maxx
     */
    public static double getMaxX() {
        return maxX;
    }

    /**
     * getter for maxy
     * @return maxy
     */
    public static double getMaxY() {
        return maxY;
    }

    /**
     * getter for x
     * @return x
     */
    public double getX() {
        return x;
    }

    /**
     * setter for x
     * @param x - x value
     */
    public void setX(double x) {
        this.x = x;
    }

    /**
     * getter for y
     * @return y
     */
    public double getY() {
        return y;
    }

    /**
     * setter for y
     * @param y - y value
     */
    public void setY(double y) {
        this.y = y;
    }
}
