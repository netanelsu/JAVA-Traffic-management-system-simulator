package utilities;

/**
 * aoop20 Hm2
 * @author eyal bismuth - 308200203
 * @author netanel sudai - 316004878
 * enum that represent vehicle type and speed
 */
public enum VehicleType {
    car(9), bus(6), bicycle(4), motorcycle(12), truck(8),
    tram(5), semitrailer(8);
    private int averageSpeed;
    VehicleType(int speed) {
        averageSpeed=speed;
    }
    public int getAverageSpeed() {
        return averageSpeed;
    }
}
