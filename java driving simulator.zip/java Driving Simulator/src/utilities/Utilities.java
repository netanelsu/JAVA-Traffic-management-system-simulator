package utilities;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * aoop20 Hm2
 * @author eyal bismuth - 308200203
 * @author netanel sudai - 316004878
 * interface utilites for simple tasks necceasry for the program
 */
public interface Utilities {
    Random random = new Random();

    /**
     * checkvalue checks if a val is in the right range
     * @param Val - value to check
     * @param min - min bound
     * @param max - max bound
     * @return true/false
     */
    default public boolean checkValue(double Val, double min, double max){
        return Val <= max && Val >= min;
    };

    /**
     * a method that prints a message that value was wrong and has been replaced
     * @param wrongVal - wrong value
     * @param correctVal - new value
     * @param varName - variable name
     */

    default public void correctingMessage(double wrongVal, double correctVal, String varName){
        System.out.println("therefore has been therefore has been replaced with " + correctVal);
    };

    /**
     * a method that prints an error message that the value is not in the right range
     * @param wrongVal - wrong value
     * @param varName - variable name
     */
    default public void errorMessage(double wrongVal, String varName){
        System.out.print("the value " + wrongVal + "for" + varName + ", ");
    };

    /**
     * a method that randomise boolean value
     * @return boolean value
     */
    default public boolean getRandomBoolean(){
        return random.nextBoolean();
    };

    /**
     * a method that randomise a double value in a bound
     * @param min - min bound
     * @param max - max bound
     * @return double value in range min -> max
     */
    default public double getRandomDouble(double min, double max){
        return ThreadLocalRandom.current().nextDouble(min, max);
    };

    /**
     * a method that randomise a int value in a bound
     * @param min - min bound
     * @param max - max bound
     * @return int value in range min -> max
     */
    default public int getRandomInt(int min, int max){
        return ThreadLocalRandom.current().nextInt(min, max);
    };

    /**
     * a method that randomise an array of int values in bound
     * @param min - min bound
     * @param max - max bound
     * @param arraySize array size
     * @return array of int values in range min -> max
     */
    default public ArrayList<Integer> getRandomIntArray(int min, int max, int arraySize){
        ArrayList <Integer> temp = new ArrayList<>(arraySize);
        for(int i = 0; i < arraySize;i ++){
            temp.add(getRandomInt(min, max));
        }
        return temp;
    };
    /**
     * a method that print creation success
     * @param objName - string that represent an object that was created
     */
    default public void successMessage(String objName){
        System.out.println(objName + " has been created");
    };
}
