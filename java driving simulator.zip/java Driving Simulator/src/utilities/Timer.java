package utilities;

/**
 * timer interface to increment all timed elements
 */
public interface Timer extends Runnable {
    public void incrementDrivingTime();
    public void Resume();

    ;
}
